# CTV-AI v1.2.1 — Comedy Break Assistant

Adds an opt-in workplace comedy assistant for burnout breaks.

## Added
- `ctv-ai-comedy` in Open WebUI
- Comedy routing
- Employee-controlled comedy profiles
- Safe roast topics and off-limits topics
- Consent-based personal roasting
- Database migration `0003`

## Apply
Extract to a temporary folder, then run:

```powershell
Set-ExecutionPolicy -Scope Process RemoteSigned
.\apply_update.ps1
```

Then:

```powershell
cd B:\CTV_AI\backend
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Add to `.env`:

```text
OLLAMA_COMEDY_MODEL=qwen3:14b
```

Run migration:

```powershell
python -m alembic upgrade head
python -m alembic current
```

Expected: `0003 (head)`

Start:

```powershell
.\start.ps1
```

New endpoints:
- `GET /api/v1/comedy/profile`
- `PUT /api/v1/comedy/profile`

Example profile:

```json
{
  "preferred_language": "Taglish",
  "humor_level": "spicy",
  "likes": ["camera jokes", "editing jokes", "IT disasters"],
  "safe_roast_topics": ["too many hard drives", "always fixing the NAS"],
  "off_limit_topics": ["family", "appearance", "health"],
  "consent_to_roasting": true
}
```

Refresh Open WebUI models and select `ctv-ai-comedy`.

Commit:

```powershell
git add .
git commit -m "feat(comedy): add opt-in employee comedy assistant"
git tag v1.2.1
git push origin main
git push origin v1.2.1
```
