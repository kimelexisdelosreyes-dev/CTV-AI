"""create comedy profiles
Revision ID: 0003
Revises: 0002
Create Date: 2026-07-10
"""
from typing import Sequence,Union
from alembic import op
import sqlalchemy as sa
revision="0003"; down_revision="0002"; branch_labels=None; depends_on=None
def upgrade():
    op.create_table("comedy_profiles",sa.Column("user_email",sa.String(320),nullable=False),sa.Column("preferred_language",sa.String(50),nullable=False),sa.Column("humor_level",sa.String(50),nullable=False),sa.Column("likes_json",sa.Text(),nullable=False),sa.Column("safe_roast_topics_json",sa.Text(),nullable=False),sa.Column("off_limit_topics_json",sa.Text(),nullable=False),sa.Column("consent_to_roasting",sa.Boolean(),nullable=False),sa.Column("updated_at",sa.DateTime(timezone=True),server_default=sa.text("now()"),nullable=False),sa.PrimaryKeyConstraint("user_email"))
def downgrade(): op.drop_table("comedy_profiles")
