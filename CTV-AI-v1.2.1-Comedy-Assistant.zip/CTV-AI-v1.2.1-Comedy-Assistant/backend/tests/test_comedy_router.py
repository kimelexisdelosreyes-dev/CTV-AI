from app.services.intent_router import intent_router
def test_routes_comedy_for_roast(): assert intent_router.route("Roast me, I am burned out").assistant=="comedy"
def test_routes_comedy_for_burnout(): assert intent_router.route("Give me a funny burnout break").assistant=="comedy"
def test_manual_comedy_override():
    r=intent_router.route("Anything",override="comedy"); assert r.assistant=="comedy" and r.confidence==1.0
