from sqlalchemy.ext.asyncio import AsyncSession
from app.core.model_registry import MODEL_REGISTRY
from app.core.prompts import ASSISTANT_PROMPTS
from app.db.models.orchestrator_event import OrchestratorEvent
from app.schemas.orchestrator import RouteDecision
from app.services.comedy_profile_service import build_profile_context,get_profile
from app.services.intent_router import intent_router
from app.services.ollama_service import ollama_service
class OrchestratorService:
    async def decide(self,message:str,override:str="auto") -> RouteDecision:
        intent=intent_router.route(message,override); profile=MODEL_REGISTRY[intent.assistant]
        available=await ollama_service.list_models(); model=profile.ollama_model; reason=intent.reason
        if model not in available:
            model=MODEL_REGISTRY["general"].ollama_model; reason=f"{reason}; configured model unavailable, falling back to {model}"
        return RouteDecision(assistant=intent.assistant,model=model,confidence=intent.confidence,reason=reason)
    async def chat(self,message,conversation,override,user_email,db:AsyncSession):
        route=await self.decide(message,override); key=route.assistant if route.assistant in ASSISTANT_PROMPTS else "general"
        system=ASSISTANT_PROMPTS[key].strip()
        if key=="comedy": system=f"{system}

{build_profile_context(await get_profile(db,user_email))}"
        messages=[{"role":"system","content":system},*[i for i in conversation if i.get("role") in {"user","assistant"} and i.get("content")],{"role":"user","content":message}]
        response=await ollama_service.chat(messages=messages,model=route.model)
        db.add(OrchestratorEvent(user_email=user_email,message_preview=message[:500],selected_assistant=route.assistant,selected_model=route.model,confidence=route.confidence,reason=route.reason)); await db.commit()
        return response,route
orchestrator_service=OrchestratorService()
