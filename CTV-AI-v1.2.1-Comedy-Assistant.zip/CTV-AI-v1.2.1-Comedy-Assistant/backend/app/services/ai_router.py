from app.core.prompts import ASSISTANT_PROMPTS
from app.schemas.chat import AssistantName
from app.services.ollama_service import ollama_service
MODEL_TO_ASSISTANT={"ctv-ai-general":"general","ctv-ai-production":"production","ctv-ai-graphics":"graphics","ctv-ai-drone":"drone","ctv-ai-it":"it"}
class AIRouter:
    @staticmethod
    def supported_models(): return ["ctv-ai-auto","ctv-ai-comedy",*MODEL_TO_ASSISTANT]
    @staticmethod
    def assistant_for_model(model): return "comedy" if model=="ctv-ai-comedy" else MODEL_TO_ASSISTANT.get(model,"general")
    @staticmethod
    def build_messages(messages,assistant):
        return [{"role":"system","content":ASSISTANT_PROMPTS[assistant].strip()},*[m for m in messages if m.get("role")!="system"]]
    async def chat(self,message:str,assistant:AssistantName):
        return await ollama_service.chat(self.build_messages([{"role":"user","content":message}],assistant))
ai_router=AIRouter()
