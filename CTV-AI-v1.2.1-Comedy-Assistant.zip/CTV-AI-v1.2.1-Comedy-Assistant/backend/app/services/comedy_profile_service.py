import json
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.models.comedy_profile import ComedyProfile
from app.schemas.comedy import ComedyProfilePublic, ComedyProfileUpdate

def _decode(value: str) -> list[str]:
    try:
        data=json.loads(value)
        return data if isinstance(data,list) else []
    except json.JSONDecodeError:
        return []

def to_public(p: ComedyProfile) -> ComedyProfilePublic:
    return ComedyProfilePublic(user_email=p.user_email, preferred_language=p.preferred_language, humor_level=p.humor_level, likes=_decode(p.likes_json), safe_roast_topics=_decode(p.safe_roast_topics_json), off_limit_topics=_decode(p.off_limit_topics_json), consent_to_roasting=p.consent_to_roasting)

async def get_profile(db: AsyncSession, user_email: str) -> ComedyProfile|None:
    r=await db.execute(select(ComedyProfile).where(ComedyProfile.user_email==user_email))
    return r.scalar_one_or_none()

async def upsert_profile(db: AsyncSession, user_email: str, payload: ComedyProfileUpdate) -> ComedyProfile:
    p=await get_profile(db,user_email)
    values=dict(preferred_language=payload.preferred_language, humor_level=payload.humor_level, likes_json=json.dumps(payload.likes), safe_roast_topics_json=json.dumps(payload.safe_roast_topics), off_limit_topics_json=json.dumps(payload.off_limit_topics), consent_to_roasting=payload.consent_to_roasting)
    if p is None:
        p=ComedyProfile(user_email=user_email, **values); db.add(p)
    else:
        for k,v in values.items(): setattr(p,k,v)
    await db.commit(); await db.refresh(p); return p

def build_profile_context(p: ComedyProfile|None) -> str:
    if p is None:
        return "No comedy profile exists. Use general workplace and multimedia humor. Do not target a specific employee."
    pub=to_public(p)
    roast = "Friendly roasting is allowed only within approved topics." if pub.consent_to_roasting else "Personal roasting is not allowed; use general humor only."
    return f"""Employee comedy profile:
Preferred language: {pub.preferred_language}
Humor level: {pub.humor_level}
Likes: {pub.likes}
Approved roast topics: {pub.safe_roast_topics}
Off-limits topics: {pub.off_limit_topics}
Consent: {pub.consent_to_roasting}
Rules: {roast} Never use off-limits topics or infer sensitive traits."""
