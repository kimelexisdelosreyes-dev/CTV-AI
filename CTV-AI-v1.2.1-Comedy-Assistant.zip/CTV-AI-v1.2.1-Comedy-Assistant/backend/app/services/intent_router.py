import re
from dataclasses import dataclass
@dataclass(frozen=True)
class IntentResult:
    assistant: str
    confidence: float
    reason: str
RULES={
"comedy":("make me laugh","tell me a joke","joke","roast me","roast us","roast the team","burned out","burnt out","burnout","stress break","funny","humor","comedy","team banter","fake awards","office jokes"),
"graphics":("adobe firefly","firefly prompt","poster","thumbnail","branding","graphic design","photoshop","after effects","typography","logo","banner"),
"production":("documentary","shot list","call sheet","interview questions","voice-over","voice over","cinematography","davinci resolve","premiere pro","editing workflow","production schedule","storyboard","b-roll","b roll"),
"drone":("drone","aerial","flight plan","battery flight","mavic","dji","no-fly","no fly","wind speed","takeoff"),
"it":("nas","network","docker","windows","postgresql","qdrant","server","router","switch","smb","storage","backup","ip address","firewall"),
"coder":("python","powershell","javascript","typescript","fastapi","sqlalchemy","api endpoint","write code","debug code","stack trace","github","git ")}
class IntentRouter:
    def route(self,message:str,override:str="auto") -> IntentResult:
        if override!="auto": return IntentResult(override,1.0,"Manual assistant override")
        normalized=re.sub(r"\s+"," ",message.lower()).strip(); scores={k:0 for k in RULES}; matched={k:[] for k in RULES}
        for a,phrases in RULES.items():
            for phrase in phrases:
                if phrase in normalized: scores[a]+=1; matched[a].append(phrase)
        best=max(scores,key=scores.get); score=scores[best]
        if score==0: return IntentResult("general",0.55,"No specialist keywords matched; using general assistant")
        total=sum(scores.values()); confidence=min(0.98,0.65+(score/max(total,1))*0.3)
        return IntentResult(best,round(confidence,2),f"Matched: {', '.join(matched[best][:4])}")
intent_router=IntentRouter()
