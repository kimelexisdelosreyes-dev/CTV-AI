from fastapi import APIRouter
from app.api.routes import auth,chat,comedy,health,infrastructure,openai_compat,orchestrator,version
api_router=APIRouter()
for r in (health.router,version.router,infrastructure.router,auth.router,comedy.router,orchestrator.router,chat.router): api_router.include_router(r)
openai_router=APIRouter(); openai_router.include_router(openai_compat.router)
