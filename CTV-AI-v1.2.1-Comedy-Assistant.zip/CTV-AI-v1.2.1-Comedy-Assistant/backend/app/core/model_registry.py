from dataclasses import dataclass
from app.core.config import settings
@dataclass(frozen=True)
class ModelProfile:
    key: str
    ollama_model: str
    capabilities: tuple[str, ...]
    description: str

def get_model_registry() -> dict[str, ModelProfile]:
    return {
        "general": ModelProfile("general", settings.ollama_general_model, ("general","reasoning","writing"), "General assistance"),
        "production": ModelProfile("production", settings.ollama_production_model, ("production","documentary","editing"), "Production and documentary"),
        "graphics": ModelProfile("graphics", settings.ollama_graphics_model, ("graphics","branding","firefly"), "Graphics and prompts"),
        "drone": ModelProfile("drone", settings.ollama_drone_model, ("drone","flight","cinematography"), "Drone operations"),
        "it": ModelProfile("it", settings.ollama_it_model, ("it","network","nas","docker"), "IT support"),
        "coder": ModelProfile("coder", settings.ollama_coder_model, ("code","python","powershell"), "Programming"),
        "light": ModelProfile("light", settings.ollama_light_model, ("simple","classification"), "Light tasks"),
        "comedy": ModelProfile("comedy", settings.ollama_comedy_model, ("humor","roast","burnout","banter","taglish"), "Opt-in workplace humor"),
    }
MODEL_REGISTRY = get_model_registry()
