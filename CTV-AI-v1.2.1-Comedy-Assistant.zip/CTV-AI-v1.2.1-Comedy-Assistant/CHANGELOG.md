# Changelog

## v1.2.1
- Added opt-in workplace comedy assistant
- Added `ctv-ai-comedy`
- Added employee comedy profiles
- Added consent-based roasting and off-limits topics
- Added comedy profile API and migration
