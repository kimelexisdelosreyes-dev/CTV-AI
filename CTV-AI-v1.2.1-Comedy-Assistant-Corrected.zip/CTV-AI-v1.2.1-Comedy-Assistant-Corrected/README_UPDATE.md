# CTV-AI v1.2.1 — Comedy Assistant Corrected Build

This corrected build fixes the startup syntax error in:

```text
backend/app/services/orchestrator_service.py
```

It also includes a validation script that checks Python syntax before files are copied into the repository.

## Apply

Extract this ZIP to a temporary folder, for example:

```text
B:\CTV_AI_Update_v1.2.1-fixed
```

Open PowerShell in that folder:

```powershell
Set-ExecutionPolicy -Scope Process RemoteSigned
.\validate_package.ps1
.\apply_update.ps1
```

The default repository path is:

```text
B:\CTV_AI
```

## Then run

```powershell
cd B:\CTV_AI\backend
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m alembic upgrade head
python -m alembic current
.\start.ps1
```

Expected Alembic revision:

```text
0003 (head)
```

## Open WebUI

Refresh models. You should see:

```text
ctv-ai-comedy
```

## Commit

```powershell
cd B:\CTV_AI
git add .
git commit -m "fix(comedy): correct comedy assistant startup"
git tag v1.2.1
git push origin main
git push origin v1.2.1
```
