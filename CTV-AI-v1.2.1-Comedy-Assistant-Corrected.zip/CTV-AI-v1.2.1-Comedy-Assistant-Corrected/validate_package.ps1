$ErrorActionPreference = "Stop"
$PackageRoot = $PSScriptRoot

Write-Host "Validating Python files..." -ForegroundColor Cyan

$PythonFiles = Get-ChildItem -Path $PackageRoot -Recurse -Filter *.py -File

foreach ($File in $PythonFiles) {
    python -m py_compile $File.FullName
}

Write-Host "Python syntax validation passed." -ForegroundColor Green
