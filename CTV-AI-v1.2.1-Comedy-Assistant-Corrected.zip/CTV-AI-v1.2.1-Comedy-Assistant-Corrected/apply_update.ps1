param(
    [string]$RepoRoot = "B:\CTV_AI"
)

$ErrorActionPreference = "Stop"
$PackageRoot = $PSScriptRoot
$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$BackupRoot = Join-Path $RepoRoot "backups\v1.2.1-fixed-$Timestamp"

if (-not (Test-Path $RepoRoot)) {
    throw "Repository path not found: $RepoRoot"
}

& "$PackageRoot\validate_package.ps1"

$Files = Get-ChildItem -Path $PackageRoot -Recurse -File |
    Where-Object {
        $_.Name -notin @(
            "README_UPDATE.md",
            "apply_update.ps1",
            "validate_package.ps1"
        ) -and
        $_.FullName -notlike "*\__pycache__\*"
    }

foreach ($File in $Files) {
    $RelativePath = $File.FullName.Substring($PackageRoot.Length + 1)
    $Destination = Join-Path $RepoRoot $RelativePath

    if (Test-Path $Destination) {
        $Backup = Join-Path $BackupRoot $RelativePath
        New-Item -ItemType Directory -Force -Path (Split-Path $Backup) | Out-Null
        Copy-Item $Destination $Backup -Force
    }

    New-Item -ItemType Directory -Force -Path (Split-Path $Destination) | Out-Null
    Copy-Item $File.FullName $Destination -Force
}

Write-Host ""
Write-Host "Corrected CTV-AI v1.2.1 package applied." -ForegroundColor Green
Write-Host "Backup: $BackupRoot"
