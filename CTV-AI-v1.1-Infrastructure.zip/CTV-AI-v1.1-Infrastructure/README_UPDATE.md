# CTV-AI v1.1 Infrastructure Update

Adds:

- PostgreSQL persistence
- SQLAlchemy async database layer
- Alembic migrations
- JWT authentication
- User roles
- Admin bootstrap command
- Qdrant service and health checks
- Protected `/api/v1/auth/me` endpoint
- Infrastructure status endpoint

## Prerequisites

- Canonical CTV-AI v1.0.0 installed at `B:\CTV_AI`
- Docker Desktop running
- Ollama running locally

## Apply

Extract this package, open PowerShell in the extracted folder, then run:

```powershell
Set-ExecutionPolicy -Scope Process RemoteSigned
.\apply_update.ps1
```

The script backs up replaced files.

## Start infrastructure

```powershell
cd B:\CTV_AI\docker
docker compose up -d postgres qdrant
docker compose ps
```

## Prepare Python environment

```powershell
cd B:\CTV_AI\backend
Set-ExecutionPolicy -Scope Process RemoteSigned
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env -Force
```

Edit `.env` and replace:

```text
JWT_SECRET_KEY=CHANGE_THIS_TO_A_LONG_RANDOM_SECRET
```

Generate a secure value with:

```powershell
python -c "import secrets; print(secrets.token_urlsafe(64))"
```

## Run database migration

```powershell
python -m alembic upgrade head
```

## Create the first administrator

```powershell
python -m app.scripts.create_admin
```

Follow the prompts. The password is hidden while typing.

## Start CTV-AI

```powershell
.\start.ps1
```

## Endpoints

- `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`
- `GET /api/v1/infrastructure/status`
- Existing chat and OpenAI-compatible endpoints remain available

## Login request

The login endpoint uses OAuth2 form fields:

```text
username: administrator email
password: administrator password
```

## Tests

```powershell
python -m pytest
```

## Commit

```powershell
cd B:\CTV_AI
git add .
git commit -m "feat(infra): add PostgreSQL Qdrant and JWT authentication"
git tag v1.1.0
git push origin main
git push origin v1.1.0
```
