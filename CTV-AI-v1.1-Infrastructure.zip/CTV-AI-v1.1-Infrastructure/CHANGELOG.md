# Changelog

## v1.1.0

### Added

- PostgreSQL persistence
- Async SQLAlchemy database layer
- Alembic migrations
- JWT login and current-user endpoints
- User roles
- Administrator bootstrap command
- Qdrant service
- Infrastructure health endpoint
- Security documentation

## v1.0.0

### Added

- Canonical FastAPI backend
- Ollama service
- OpenAI-compatible API
- Open WebUI support
- Streaming chat completions
- Five specialist assistants
- Health and version endpoints
- Environment-based configuration
- Logging
- Tests
- Docker support
- Windows scripts
- Documentation
