param(
    [string]$RepoRoot = "B:\CTV_AI"
)

$ErrorActionPreference = "Stop"
$PackageRoot = $PSScriptRoot
$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$BackupRoot = Join-Path $RepoRoot "backups\v1.1-$Timestamp"

if (-not (Test-Path $RepoRoot)) {
    throw "Repository path not found: $RepoRoot"
}

$Files = Get-ChildItem -Path $PackageRoot -Recurse -File |
    Where-Object {
        $_.FullName -notlike "*README_UPDATE.md" -and
        $_.FullName -notlike "*apply_update.ps1"
    }

foreach ($File in $Files) {
    $RelativePath = $File.FullName.Substring($PackageRoot.Length + 1)
    $Destination = Join-Path $RepoRoot $RelativePath

    if (Test-Path $Destination) {
        $Backup = Join-Path $BackupRoot $RelativePath
        New-Item -ItemType Directory -Force -Path (Split-Path $Backup) | Out-Null
        Copy-Item $Destination $Backup -Force
    }

    New-Item -ItemType Directory -Force -Path (Split-Path $Destination) | Out-Null
    Copy-Item $File.FullName $Destination -Force
}

Write-Host ""
Write-Host "CTV-AI v1.1 update applied." -ForegroundColor Green
Write-Host "Backup: $BackupRoot"
Write-Host ""
Write-Host "Read README_UPDATE.md before starting the services."
