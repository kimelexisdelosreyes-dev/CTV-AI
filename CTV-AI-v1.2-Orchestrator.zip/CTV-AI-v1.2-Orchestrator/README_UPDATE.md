# CTV-AI v1.2 — Multi-Model AI Orchestrator

This update adds a production-ready first version of the CTV-AI Orchestrator.

## What it adds

- Automatic specialist routing
- Multi-model registry
- Per-specialist model selection
- Fallback to the default Ollama model
- Manual assistant override
- Routing preview endpoint
- Protected orchestrated chat endpoint
- Open WebUI model `ctv-ai-auto`
- PostgreSQL audit records for routing decisions
- Ollama model availability checks
- Automated tests

## Apply the update

Extract this ZIP to a temporary folder such as:

```text
B:\CTV_AI_Update_v1.2
```

Then open PowerShell in that extracted folder:

```powershell
Set-ExecutionPolicy -Scope Process RemoteSigned
.\apply_update.ps1
```

The script assumes the repository is:

```text
B:\CTV_AI
```

A backup of replaced files is created automatically.

## Update dependencies and environment

```powershell
cd B:\CTV_AI\backend
Set-ExecutionPolicy -Scope Process RemoteSigned
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Open `.env` and confirm these values:

```text
OLLAMA_MODEL=qwen3:14b
OLLAMA_GENERAL_MODEL=qwen3:14b
OLLAMA_PRODUCTION_MODEL=qwen3:14b
OLLAMA_GRAPHICS_MODEL=qwen3:14b
OLLAMA_DRONE_MODEL=qwen3:14b
OLLAMA_IT_MODEL=qwen3:14b
OLLAMA_CODER_MODEL=qwen3:14b
OLLAMA_LIGHT_MODEL=qwen3:14b
```

These all use the installed model for now. Later, you can assign different models without changing code.

## Run the database migration

```powershell
python -m alembic upgrade head
python -m alembic current
```

Expected current revision:

```text
0002 (head)
```

## Start CTV-AI

```powershell
.\start.ps1
```

## New endpoints

- `POST /api/v1/orchestrator/route`
- `POST /api/v1/orchestrator/chat`
- `GET /api/v1/orchestrator/models`
- Existing `/v1/models` now includes `ctv-ai-auto`

These endpoints require JWT authentication.

## Test routing

In Swagger, authorize with your admin account, then call:

```json
POST /api/v1/orchestrator/route

{
  "message": "Create an Adobe Firefly prompt for a cinematic real-estate video"
}
```

Expected assistant:

```text
graphics
```

Test:

```json
{
  "message": "My NAS is not showing in Windows"
}
```

Expected assistant:

```text
it
```

## Open WebUI

Your OpenAI-compatible connection should automatically discover:

```text
ctv-ai-auto
```

Select `ctv-ai-auto` to let CTV-AI choose the specialist automatically.

## Run tests

```powershell
python -m pytest
```

## Commit

```powershell
cd B:\CTV_AI
git add .
git commit -m "feat(orchestrator): add multi-model automatic routing"
git tag v1.2.0
git push origin main
git push origin v1.2.0
```
